// color1= 

getElementById("color1").style.background= color1